readChannelID = 3412312;
readKey = 'DCKLQE8W1GY9BT4I';

inicioDia = datetime('today');
ahora = datetime('now');

data = thingSpeakRead(readChannelID, 'Fields', 4, ...
    'DateRange', [inicioDia, ahora], ...
    'ReadKey', readKey, 'OutputFormat', 'table');

if isempty(data)
    text(0.5, 0.5, 'Sin datos aun', 'HorizontalAlignment', 'center', 'FontSize', 14);
    return;
end

motivos = data{:,2};
tiempo = data.Timestamps;

% Filtrar solo entradas con error
mask = ~cellfun('isempty', motivos);
motivos = motivos(mask);
tiempo = tiempo(mask);

if isempty(motivos)
    text(0.5, 0.5, 'Sin errores registrados hoy', ...
        'HorizontalAlignment', 'center', 'FontSize', 14);
    return;
end

% Asignar valor numerico a cada tipo de error
tipos = zeros(length(motivos), 1);
for i = 1:length(motivos)
    if strcmp(motivos{i}, 'Timeout_lectura')
        tipos(i) = 1;
    elseif strcmp(motivos{i}, 'Cliente_no_coincide')
        tipos(i) = 2;
    elseif strcmp(motivos{i}, 'Atasco_confirmacion')
        tipos(i) = 3;
    end
end

% Colores por tipo
colores_mapa = [0.9 0.3 0.3; 0.9 0.6 0.1; 0.5 0.2 0.7];

hold on;
for i = 1:length(tipos)
    scatter(tiempo(i), tipos(i), 120, colores_mapa(tipos(i),:), 'filled');
end

yticks([1 2 3]);
yticklabels({'Timeout lectura', 'Cliente no coincide', 'Atasco confirmacion'});
ylim([0.5 3.5]);
xlabel('Hora', 'FontSize', 12);
title(sprintf('Errores en el tiempo - Total: %d errores hoy', length(motivos)), ...
    'FontSize', 13, 'FontWeight', 'bold');
grid on;

legend({'Timeout lectura', 'Cliente no coincide', 'Atasco confirmacion'}, ...
    'Location', 'best', 'FontSize', 10);
