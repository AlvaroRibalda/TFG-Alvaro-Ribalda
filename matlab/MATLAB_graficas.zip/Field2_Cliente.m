readChannelID = 3412312;
readKey = 'DCKLQE8W1GY9BT4I';

inicioDia = datetime('today');
ahora = datetime('now');

data = thingSpeakRead(readChannelID, 'Fields', 2, ...
    'DateRange', [inicioDia, ahora], ...
    'ReadKey', readKey, 'OutputFormat', 'table');

if isempty(data)
    text(0.5, 0.5, 'Sin datos aun', 'HorizontalAlignment', 'center', 'FontSize', 14);
    return;
end

clientes = data{:,2};

atm = sum(strcmp(clientes, 'ATM'));
vrx = sum(strcmp(clientes, 'VRX'));
nds = sum(strcmp(clientes, 'NDS'));
slc = sum(strcmp(clientes, 'SLC'));

nombres = {'ATM', 'VRX', 'NDS', 'SLC'};
valores_todos = [atm, vrx, nds, slc];

% Filtrar solo los que tienen piezas
mask = valores_todos > 0;
valores = valores_todos(mask);
nombres_filtrados = nombres(mask);
total = sum(valores);

if total == 0
    text(0.5, 0.5, 'Sin datos aun', 'HorizontalAlignment', 'center', 'FontSize', 14);
    return;
end

% Colores distintos para cada trozo
colores = lines(length(valores));

etiquetas = cellfun(@(n,v) sprintf('%s: %.0f%% (%d piezas)', n, 100*v/total, v), ...
    nombres_filtrados, num2cell(valores), 'UniformOutput', false);

p = pie(valores);

% Aplicar colores manualmente a cada trozo
for i = 1:length(valores)
    p(i*2-1).FaceColor = colores(i,:);
    p(i*2).String = etiquetas{i};
end

title(sprintf('Distribucion por cliente - Total: %d piezas', total), ...
    'FontSize', 13, 'FontWeight', 'bold');
