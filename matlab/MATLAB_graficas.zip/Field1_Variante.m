readChannelID = 3412312;
readKey = 'DCKLQE8W1GY9BT4I';

inicioDia = datetime('today', 'TimeZone', 'Europe/Madrid');
ahora = datetime('now', 'TimeZone', 'Europe/Madrid');

data = thingSpeakRead(readChannelID, 'Fields', 1, ...
    'DateRange', [inicioDia, ahora], ...
    'ReadKey', readKey, 'OutputFormat', 'table');

if isempty(data)
    text(0.5, 0.5, 'Sin datos hoy aun', 'HorizontalAlignment', 'center', 'FontSize', 14);
    return;
end

variante = data{:,2};
tiempo = data.Timestamps;

idx_NA = strcmp(variante, 'NA');
idx_EU = strcmp(variante, 'EU');

na_total = sum(idx_NA);
eu_total = sum(idx_EU);

scatter(tiempo(idx_NA), ones(sum(idx_NA),1), 70, 'b', 'filled'); hold on;
scatter(tiempo(idx_EU), 2*ones(sum(idx_EU),1), 70, 'r', 'filled');

yticks([1 2]);
yticklabels({'NA','EU'});
ylim([0.5 2.5]);
xlabel('Hora');
ylabel('Variante');
title(sprintf('Variantes hoy (%s) - NA: %d | EU: %d piezas', ...
    datestr(ahora, 'dd/mm/yyyy'), na_total, eu_total), ...
    'FontSize', 12, 'FontWeight', 'bold');
legend('NA','EU','Location','best');
grid on;
