readChannelID = 3412312;
readAPIKey = 'DCKLQE8W1GY9BT4I';

data = thingSpeakRead(readChannelID, 'Fields', [1 2 3 4 5], 'NumPoints', 200, ...
    'ReadKey', readAPIKey, 'OutputFormat', 'table');

hoy = datetime('now', 'TimeZone', 'Europe/Madrid');
inicioDia = dateshift(hoy, 'start', 'day');

figure('Color', 'w', 'Position', [0 0 640 340]);
axis off;
xlim([0 1]); ylim([0 1]);

titulo = sprintf('Piezas procesadas hoy - %s', datestr(hoy, 'dd/mm/yyyy'));
text(0.5, 0.97, titulo, 'HorizontalAlignment', 'center', ...
    'FontSize', 13, 'FontWeight', 'bold', 'Units', 'normalized');

if isempty(data) || width(data) < 6
    text(0.5, 0.5, 'Sin datos aun', 'HorizontalAlignment', 'center', ...
        'FontSize', 12, 'Color', [0.6 0.6 0.6], 'Units', 'normalized');
    return;
end

ts = data{:,1};
if isempty(ts.TimeZone)
    ts.TimeZone = 'UTC';
end
ts.TimeZone = 'Europe/Madrid';
esHoy = (ts >= inicioDia);

timestamps = ts(esHoy);
variante = data{esHoy,2};
cliente = data{esHoy,3};
resultado = data{esHoy,4};
motivo = data{esHoy,5};
serie = data{esHoy,6};

clienteVacio = cellfun(@isempty, cliente);
timestamps = timestamps(~clienteVacio);
variante = variante(~clienteVacio);
cliente = cliente(~clienteVacio);
resultado = resultado(~clienteVacio);
motivo = motivo(~clienteVacio);
serie = serie(~clienteVacio);

if isempty(cliente)
    text(0.5, 0.5, 'Sin piezas procesadas hoy', 'HorizontalAlignment', 'center', ...
        'FontSize', 12, 'Color', [0.6 0.6 0.6], 'Units', 'normalized');
    return;
end

[timestamps, idxOrden] = sort(timestamps, 'descend');
variante = variante(idxOrden);
cliente = cliente(idxOrden);
resultado = resultado(idxOrden);
motivo = motivo(idxOrden);
serie = serie(idxOrden);

n = min(numel(cliente), 12);

lineas = sprintf('%-6s %-6s %-8s %-9s %-8s %-s\n', ...
    'Hora', 'Serie', 'Cliente', 'Variante', 'Result.', 'Motivo Error');
lineas = [lineas, repmat('-', 1, 60), newline];

for i = 1:n
    hora = datestr(timestamps(i), 'HH:MM');
    if resultado(i) == 1
        res = 'OK';
    else
        res = 'ERROR';
    end
    lineas = [lineas, sprintf('%-6s %-6s %-8s %-9s %-8s %-s\n', ...
        hora, serie{i}, cliente{i}, variante{i}, res, motivo{i})];
end

text(0.02, 0.85, lineas, 'FontName', 'Courier New', 'FontSize', 10, ...
    'VerticalAlignment', 'top', 'Units', 'normalized', 'Interpreter', 'none');
