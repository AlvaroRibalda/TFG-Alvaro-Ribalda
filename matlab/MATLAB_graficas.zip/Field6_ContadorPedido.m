readChannelID = 3412312;
readAPIKey = 'DCKLQE8W1GY9BT4I';
fieldID = 6;

data = thingSpeakRead(readChannelID, 'Fields', fieldID, 'NumPoints', 20, ...
    'ReadKey', readAPIKey, 'OutputFormat', 'table');

figure('Color','w');

if isempty(data)
    text(0.5, 0.5, 'Sin datos', 'HorizontalAlignment', 'center', 'FontSize', 12);
    axis off;
    return;
end

textos = data{:,2};
textosValidos = textos(~cellfun(@isempty, textos));

if isempty(textosValidos)
    text(0.5, 0.5, 'Sin pedido activo', 'HorizontalAlignment', 'center', ...
        'FontSize', 13, 'FontWeight', 'bold');
    axis off;
    return;
end

texto = textosValidos{end}; % ultimo valor NO vacio, ej. "3/5"
partes = split(texto, '/');

if numel(partes) ~= 2
    axis off;
    text(0.5, 0.5, 'Sin pedido activo', 'HorizontalAlignment', 'center', 'FontSize', 13);
    return;
end

actual = str2double(partes{1});
total = str2double(partes{2});

if isnan(actual) || isnan(total) || total == 0
    axis off;
    text(0.5, 0.5, 'Sin pedido activo', 'HorizontalAlignment', 'center', 'FontSize', 13);
    return;
end

porcentaje = (actual / total) * 100;

barh(1, porcentaje, 'FaceColor', [0.20 0.55 0.85], 'BarWidth', 0.5);
hold on;
barh(1, 100, 'FaceColor', 'none', 'EdgeColor', 'k', 'LineWidth', 1.5, 'BarWidth', 0.5);
xlim([0 100]);
ylim([0.5 1.5]);
set(gca, 'YTick', [], 'XTick', 0:20:100);
xlabel('Progreso (%)');
title(sprintf('Pedido en curso: %d / %d unidades (%.0f %%)', actual, total, porcentaje), ...
    'FontSize', 12);
grid on;
