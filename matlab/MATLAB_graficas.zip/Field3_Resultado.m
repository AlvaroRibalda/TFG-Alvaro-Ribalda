readChannelID = 3412312;
readAPIKey = 'DCKLQE8W1GY9BT4I';

data = thingSpeakRead(readChannelID, 'Fields', [1 2 3], 'NumPoints', 200, ...
    'ReadKey', readAPIKey, 'OutputFormat', 'table');

hoy = datetime('now', 'TimeZone', 'Europe/Madrid');
inicioDia = dateshift(hoy, 'start', 'day');

figure('Color', 'w');
axis off;
xlim([0 1]); ylim([0 1]);

titulo = sprintf('Tasa de exito - %s', datestr(hoy, 'dd/mm/yyyy'));
text(0.5, 0.95, titulo, 'HorizontalAlignment', 'center', ...
    'FontSize', 13, 'FontWeight', 'bold', 'Units', 'normalized');

if isempty(data) || width(data) < 4
    text(0.5, 0.5, 'Sin datos aun', 'HorizontalAlignment', 'center', ...
        'FontSize', 12, 'Color', [0.6 0.6 0.6], 'Units', 'normalized');
    return;
end

ts = data{:,1};
if isempty(ts.TimeZone)
    ts.TimeZone = 'UTC';
end
ts.TimeZone = 'Europe/Madrid';
esHoy = (ts >= inicioDia);

clientesTodos = data{:,3};
resultadosTodos = data{:,4};

clientes = clientesTodos(esHoy);
resultados = resultadosTodos(esHoy);

clienteVacio = cellfun(@isempty, clientes);
resultadosPiezas = resultados(~clienteVacio);
totalPiezas = numel(resultadosPiezas);

if totalPiezas == 0
    text(0.5, 0.5, 'Sin piezas procesadas hoy', 'HorizontalAlignment', 'center', ...
        'FontSize', 12, 'Color', [0.6 0.6 0.6], 'Units', 'normalized');
    return;
end

numOK = sum(resultadosPiezas == 1);
numError = totalPiezas - numOK;
porcentaje = 100 * numOK / totalPiezas;

if porcentaje >= 90
    color = [0.20 0.70 0.20];
elseif porcentaje >= 70
    color = [0.95 0.60 0.10];
else
    color = [0.85 0.10 0.10];
end

text(0.5, 0.55, sprintf('%.0f%%', porcentaje), 'HorizontalAlignment', 'center', ...
    'FontSize', 60, 'FontWeight', 'bold', 'Color', color, 'Units', 'normalized');
text(0.5, 0.30, 'de exito hoy', 'HorizontalAlignment', 'center', ...
    'FontSize', 13, 'Color', [0.5 0.5 0.5], 'Units', 'normalized');
text(0.5, 0.12, sprintf('%d OK | %d ERROR | %d total', numOK, numError, totalPiezas), ...
    'HorizontalAlignment', 'center', 'FontSize', 11, 'Color', [0.5 0.5 0.5], 'Units', 'normalized');
