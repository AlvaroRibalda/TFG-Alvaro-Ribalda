% Field 8: Semáforo de estado - SDX200
readChannelID = 3412312;
readAPIKey = 'DCKLQE8W1GY9BT4I';
fieldID = 8;

data = thingSpeakRead(readChannelID, 'Fields', fieldID, 'NumPoints', 1, ...
    'ReadKey', readAPIKey, 'OutputFormat', 'table');

if isempty(data)
    figure('Color','w');
    text(0.5, 0.5, 'Sin datos', 'HorizontalAlignment', 'center', 'FontSize', 12);
    axis off;
    return;
end

estado = data.Estado{1};

switch estado
    case 'EN_MARCHA'
        color = [0.20 0.70 0.20]; % verde
    case 'PARADO'
        color = [0.95 0.60 0.10]; % naranja
    case 'EMERGENCIA'
        color = [0.85 0.10 0.10]; % rojo
    otherwise
        color = [0.6 0.6 0.6]; % gris - estado no reconocido
end

figure('Color','w');
theta = linspace(0, 2*pi, 100);
fill(cos(theta), sin(theta), color, 'EdgeColor', 'k', 'LineWidth', 2);
axis equal off;
title(estado, 'FontSize', 14, 'FontWeight', 'bold', 'Interpreter', 'none');
