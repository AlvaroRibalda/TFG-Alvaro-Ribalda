readChannelID = 3412312;
readKey = 'DCKLQE8W1GY9BT4I';

clf;
set(gcf, 'Color', 'w');

data = thingSpeakRead(readChannelID, 'Fields', [1 2], 'NumPoints', 200, ...
    'ReadKey', readKey, 'OutputFormat', 'table');

hoy = datetime('now', 'TimeZone', 'Europe/Madrid');
inicioDia = dateshift(hoy, 'start', 'day');

if isempty(data) || width(data) < 3
    clientes = {};
else
    ts = data{:,1};
    if isempty(ts.TimeZone)
        ts.TimeZone = 'UTC';
    end
    ts.TimeZone = 'Europe/Madrid';

    esHoy = (ts >= inicioDia);
    clientesTodos = data{:,3};

    clientes = clientesTodos(esHoy);
    clientes = clientes(~cellfun(@isempty, clientes));
end

totalHoy = numel(clientes);

nombres = {'ATM', 'VRX', 'NDS', 'SLC'};
valores = zeros(1, numel(nombres));
for i = 1:numel(nombres)
    valores(i) = sum(strcmp(clientes, nombres{i}));
end
colores_lista = [0.2 0.5 0.8; 0.3 0.7 0.4; 0.9 0.6 0.1; 0.7 0.2 0.5];

mask = valores > 0;
nombres_fil = nombres(mask);
valores_fil = valores(mask);
colores_fil = colores_lista(mask, :);

axes('Position', [0 0.88 1 0.10]);
axis off;
text(0.5, 0.5, 'Produccion de hoy - SDX200', ...
    'HorizontalAlignment', 'center', 'FontSize', 13, ...
    'FontWeight', 'bold', 'Units', 'normalized');

axes('Position', [0 0.55 1 0.30]);
axis off;
text(0.5, 0.55, sprintf('%d', totalHoy), ...
    'HorizontalAlignment', 'center', 'FontSize', 60, ...
    'FontWeight', 'bold', 'Color', [0.05 0.45 0.42], ...
    'Units', 'normalized');
text(0.5, 0.15, 'piezas clasificadas hoy', ...
    'HorizontalAlignment', 'center', 'FontSize', 12, ...
    'Color', [0.5 0.5 0.5], 'Units', 'normalized');

if ~isempty(nombres_fil) && totalHoy > 0
    axes('Position', [0.05 0.02 0.90 0.48]);
    axis off;
    xlim([0 1]);
    ylim([0 1]);

    n = length(nombres_fil);
    alto = 0.85 / n;

    for i = 1:n
        y_base = 1 - i * alto;
        porcentaje = 100 * valores_fil(i) / totalHoy;
        ancho_barra = max(0.02, 0.85 * porcentaje / 100);

        rectangle('Position', [0.10 y_base+0.02 0.85 alto*0.45], ...
            'FaceColor', [0.93 0.93 0.93], 'EdgeColor', 'none');
        rectangle('Position', [0.10 y_base+0.02 ancho_barra alto*0.45], ...
            'FaceColor', colores_fil(i,:), 'EdgeColor', 'none');
        text(0.10, y_base + alto*0.65, ...
            sprintf('%s: %d piezas (%.0f%%)', nombres_fil{i}, valores_fil(i), porcentaje), ...
            'FontSize', 11, 'FontWeight', 'bold', 'Color', colores_fil(i,:));
    end
end
